import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Bouncing_Shapes extends PApplet {



int mode=0;
//0 = no collisions
//1 = explode
//2 = agar.io mode
//3 = bounce off other shapes
ArrayList<Shape> shapes = new ArrayList<Shape>();
PVector gravity = new PVector(0, 0.1f);
PImage mouse, button;
int imagecount = 5, load = imagecount = 5, h = round(imagecount*2.5f);
boolean started, click, recording = false;
boolean hasImages = true, explosions = mode==1;
boolean bounce = mode==2, agariomode = mode==3;
ArrayList<PImage> images;
//Define explosions boolean, tells wether explosions are enabled
public Shape newShape() {
  return(random(1)<0.25f?(new Triangle())
    :(random(1)<0.33f?(new Circle())
    :(random(1)<0.4f?(new Square())
    :(new Image()))));
}
public void setup() {//Creates setup function (runs on program launch)
  frame.setTitle("Bouncing Shapes");//Set title
  //Set window size to 640X360 (360p)
  mouse = loadImage("mouseCursor.png");
  images = new ArrayList<PImage>();
  for (int i=1; i<imagecount+1; i++) {
    images.add(loadImage("image"+i+".png"));
  };
  //for (int i=0; i<25; i++) {
  //  shapes.add(newShape());
  //  //shapes.get(i).image = i%h<images.size()?images.get(i%h):mouse;
  //  //shapes.get(i).hasImage = !shapes.get(i).image.equals(mouse);
  //  //if(shapes.get(i).hasImage) shapes.get(i).pos.z*=random(1.2,1.5);
  //}
  button = loadImage("backgroundButton.png");
}
boolean displayCursor;
public void drawA() {
  frameRate(80);
  background(0);
  if (keyPressed) keyPressed = false;//Prevent spam 60 times a second of above
  frame.setTitle("Bouncing Shapes (cursor: "+(displayCursor?"en":"dis")+"abled) "+5*((int)frameRate/5)+" fps");//Set title in case of change
  for (int i=0; i<shapes.size(); i++) {
    shapes.get(i).update();
    for (int j=0; j<shapes.size(); j++) {
      if (i!=j&&explosions) shapes.get(i).check(shapes.get(j));
      if (i!=j&&bounce) shapes.get(i).check(shapes.get(j));
      if (i!=j&&agariomode) shapes.get(i).check(shapes.get(j));
    }
  }
  //if(!displayCursor){
  if (mousePressed) {
    Shape newOne = newShape();
    newOne.pos.x = mouseX;
    newOne.pos.y = mouseY;
    shapes.add(newOne);
    mousePressed=!mousePressed;
  }
  //}
  
}
public void draw() {
  frameRate(80);
  background(0);
  if (key=='c'&&keyPressed) displayCursor=!displayCursor;//toggle explosions
  if (key=='r'&&keyPressed) recording=!recording;//toggle explosions
  if(keyPressed) keyPressed=false;
  if (started&&load>=99) drawA();
  if (!started&&load<=98) {
    fill(140);
    strokeWeight(4);
    stroke(70);
    image(button, width/2-125, height/4, 250, 75);
    fill(50);
    strokeWeight(3);
    stroke(200);
    textFont(createFont("Minecrafter Alt", 36));
    text("Start", width/2-90, height/4+48+4);
    textFont(createFont("Minecrafter Alt", 12));
    text("click this button", width/2-90, height/4+48+16);
    fill(0,0,0,0);
    stroke(0,0,0,255);
    strokeWeight(2);
    rect(width/2+50,height/4+21,25,25);
    image(mouse,width/2+52,height/4+22,26,26);
    if(mouseX<width/2+128&&
    mouseX>width/2-128&&
    mouseY<height/4+48+8&&
    mouseY>height/4&&mousePressed) click=true;
    
    if(click){
     // for(int a=0; a<100; a++){
        load+=10;
        fill(255);
        rect(width/2-100,height/2,load*2,32);
        delay((int)random(1,500)/5);
        if(load>=99){
      started = true;
          for(int i=0; i<10; i++){
            shapes.add(newShape());
          }
        }
     // }
    }
  }
  if (displayCursor) noCursor();
  if (displayCursor) image(mouse, mouseX-12, mouseY-8, 32, 32);
  
  if (recording) saveFrame("frames\\####.png");
  fill(255, 0, 0);
  if (recording) ellipse(width-20, 20, 10, 10);
}
public class Particle{
  int c;
  boolean living = true;
  PVector pos = new PVector();
  PVector vel = new PVector(random(-4,4),random(-4,4));
  Particle(float x, float y, int a){
    pos.x = x;
    pos.y = y;
    c = a;
  }
  public void show(){
    strokeWeight(4);
    stroke(c);
    fill(c);
    line(pos.x,pos.y,pos.x-vel.x*2,pos.y-vel.y*2);
  }
  public void update(){
    show();
    pos.add(vel);
    vel.add(gravity);
    if(pos.x>width||pos.x<0||pos.y>height){living = false;}
  }
}
public class Shape {
  int c = color(random(255), random(255), random(255));
  PVector pos = new PVector(random(width), random(height), random(30, 32));
  PVector vel = new PVector(random(-2, 2), random(-2, 2), 0.01f);
  boolean living = true;
  int clds = 0; 
  int particlesMax = 192;
  ArrayList<Particle> particles = new ArrayList<Particle>();
  boolean hasImage;
  PImage image;
  public void kill(boolean a) {
    if (explosions) living = false;
    if(agariomode) vel.z = -2;
    if (a&&explosions) {
      for (int i=0; i<particlesMax; i++) {
        particles.add(new Particle(pos.x, pos.y, c));
      }
    }
  }
  public void kill(Shape s, boolean sdx, boolean sdy) {
    
    if (agariomode) {
      if (s.pos.z>pos.z) {
        s.vel.z+=pos.z/75;
        living = false;
      }
      if (s.pos.z<pos.z) {
        vel.z+=s.pos.z/75;
        s.living = false;
      }
    } else if (bounce) {
      PVector tmpVel;
      vel.x = !sdx?-vel.x:vel.x;
      vel.y = !sdy?-vel.y:vel.y;
    }
  }
  public void check(Shape s) {
    if (!s.living||!living) {
      return;
    }
    float r = s.pos.z>pos.z?s.pos.z:pos.z;
    boolean isCollidingX = s.pos.x>pos.x-r/2&&pos.x>s.pos.x-r/2;
    boolean isCollidingY = s.pos.y>pos.y-r/2&&pos.y>s.pos.y-r/2;
    boolean thisIsGoingLeft = vel.x<0;
    boolean thatIsGoingLeft = s.vel.x<0;
    boolean sameDirX = thisIsGoingLeft==thatIsGoingLeft;
    boolean thisIsGoingUp = vel.y<0;
    boolean thatIsGoingUp = s.vel.y<0;
    boolean sameDirY = thisIsGoingUp==thatIsGoingUp;

    if (isCollidingX&&isCollidingY) {
      if (explosions) {
        boolean a  =  random(1)>0.4999f;
        kill(a);
        s.kill(!a);
      } else if (bounce) {
        kill(s, sameDirX, sameDirY);
        s.kill(this, sameDirX, sameDirY);
      } else if (mode==2||agariomode){
        
        kill(s, sameDirX, sameDirY);
        s.kill(this, sameDirX, sameDirY);
      }
    }
  }
  public void update() {
    fill(c);
    stroke(0);
    strokeWeight(1);
    for (int i=0; i<particles.size(); i++) {
      if (particles.get(i).living) {
        particles.get(i).update();
      }
    }
    if (!living) return;
    //vel.add(gravity);
    clds-=1;
    pos.add(vel);
    if (pos.x>width-pos.z/2||pos.x<pos.z/2) {
      vel.x*=-1;
      clds+=3;
    }
    if (pos.y>height-pos.z/2||pos.y<pos.z/2) {
      vel.y*=-1;
      clds+=3;
    }
    if (clds>50) {
      kill(true);
    }
    vel.z*=0.95f;
    if (!hasImage) show();
    if (hasImage) image(image, pos.x-pos.z/2, pos.y-pos.z/2, pos.z, pos.z);
  };
  public void show() {
    //
  };
}
class Square extends Shape{
  public void show(){
    fill(c);
    stroke(0);
    strokeWeight(1);
    rect(pos.x-pos.z/2,pos.y-pos.z/2,pos.z,pos.z);
  };
}

class Circle extends Shape{
  public void show(){
    fill(c);
    stroke(0);
    strokeWeight(1);
    ellipse(pos.x,pos.y,pos.z,pos.z);
  };
}

class Triangle extends Shape{
  public void show(){
    fill(c);
    stroke(0);
    strokeWeight(1);
    triangle(pos.x-pos.z/2,pos.y-pos.z/2,pos.x+pos.z/2,pos.y-pos.z/2,pos.x,pos.y+pos.z/2);
  };
}

class Image extends Shape{
  PImage image = (images.get((int)random(images.size())));
  Image(){
    pos.z*=1.25f;
  }
  public void show(){
    image(image,pos.x-pos.z/2,pos.y-pos.z/2,pos.z,pos.z);
  }
}
  public void settings() {  size(853, 480); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Bouncing_Shapes" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
